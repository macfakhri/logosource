<?php

use Illuminate\Http\RedirectResponse;
use Illuminate\Routing\Router;
use App\Post;
/** @var $router Router */

$site = config('site');

$router->name('home')->get('/', function () use ($site) {
    return view()->render('home', [
    	'posts' => Post::inRandomOrder()->whereNotNull('content')->take(15)->get(),
    	'site' => $site
    ]);
});

$router->name('image')->get('/{slug}.html', function($slug) use ($site){
	$post = Post::where('slug', $slug)->first();

	if(is_null($post)){
		return view()->render($slug, [
	    	'site' => $site,
	    	'page' => $slug
	    ]);
	}

	return view()->render('image', [
		'keyword' => $post->keyword,
		'sentences' => $post->ingredients['sentences'],
		'images' => $post->ingredients['images'],
		'related' => $post->where('parent', $post->keyword)->whereNotNull('content')->get(),
        'post' => $post,
        'site' => $site
    ]);
});