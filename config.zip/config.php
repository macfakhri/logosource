<?php

return [
	'theme' => 'three',
	'site' => [
		'name' => 'My Awesome Site',
		'description' => 'Change this at config.php',
		'url' => 'domain.com',
		'pages' => [
			'dmca',
			'contact',
			'privacy-policy',
			'copyright',
		]
	],
	'database' => 'database.sqlite'
];