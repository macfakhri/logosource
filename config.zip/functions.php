<?php
use Illuminate\Config\Repository;
use Jenssegers\Blade\Blade;
use Illuminate\Routing\UrlGenerator;
use Illuminate\Container\Container;
use Illuminate\Http\Request;
use Illuminate\Events\Dispatcher;
use Illuminate\Routing\Router;
use Buchin\SearchTerm\SearchTerm;



function site_name()
{
	return config('site.name');
}

function route($name, $parameters = [], $absolute = true)
{
	// Create a service container
	$container = new Container;

	// Create a request from server variables, and bind it to the container; optional
	$request = Request::capture();
	$container->instance('Illuminate\Http\Request', $request);

	// Using Illuminate/Events/Dispatcher here (not required); any implementation of
	// Illuminate/Contracts/Event/Dispatcher is acceptable
	$events = new Dispatcher($container);

	// Create the router instance
	$router = new Router($events, $container);
	// Load the routes
	include 'routes.php';

	$generator = new UrlGenerator($router->getRoutes(), $request);

	return $generator->route($name, $parameters, $absolute);
}

function config($name)
{
	$config = new Repository(require __DIR__ . '/config.php');

	return $config->get($name);
}

function view()
{
	termapi();
	
	return new Blade([
		__DIR__ . '/themes/' . config('theme'),
		__DIR__ . '/themes/_ads',
		__DIR__ . '/themes/_pages',

	], __DIR__ . '/cache');
}

function image_url($post, $img = false, $thumbnail = false)
{
	if($thumbnail){

		return collect($post->ingredients['images'])->random()['thumbnail'];
	}
	if($img){
		return collect($post->ingredients['images'])->random()['image'];
	}

	return route('image', $post->slug);
}

function home_url()
{
	return route('home');
}

function pages()
{
	return config('site.pages');
}

function page_url($page)
{
	return route('image', $page);
}

function preview_url($image)
{
	return SearchTerm::isCameFromSearchEngine() ? home_url() . '?img=' . urlencode($image['url']) : $image['url'];
}