<?php $__env->startSection('content'); ?>
<article>
    <h1>Contact</h1>

    <p align="justify">Have any question, comment, suggestion or news tip to pass along to <?php echo e($site['name']); ?>?</p>
    <p align="justify">We are open to discuss all of the possibilities with you. This page offering the right way to sent any comments to&nbsp; admin related to your feedback, news coverage and other issues related to this site.</p>
    <p>We are happy to hear information from you please write a subject format:</p>
    <ul>
    <li><strong>Claim Picture</strong>&nbsp;[picture name] [url to real picture] : if you are the real owner to claim your picture and need back links.</li>
    <li><strong>Submit Wallpapers</strong>&nbsp;[wallpaper name] : if you wanna submit your or your wallpaper design to us.</li>
    <li><strong>Advertise</strong>&nbsp;: if you interested to advertising on our site.</li>
    <li><strong>Support</strong> : if you need our support.</li>
    </ul>
    <p>And send all your inquiries to our official mail at contact@domainname</p>
    <p align="justify">Don’t hesitate to contact us according your concerns and don’t worry, all of your comment are welcome. :) </p>
    <p align="justify">Thank you.</p>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/buchin/Repos/shuriken-native/themes/_pages/contact.blade.php ENDPATH**/ ?>