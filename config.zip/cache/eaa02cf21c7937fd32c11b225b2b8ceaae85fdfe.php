<?php $__env->startSection('head'); ?>
<title><?php echo e(ucwords($keyword)); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bg'); ?>
<?php echo e(collect($images)->random()['url']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="posts-single">
	<h1><?php echo e(ucwords($keyword)); ?></h1>

	<?php
		shuffle($sentences);
	?>
	
	<div class="navi text-left">
		<?php if(!empty($sentences)): ?>
			<p><?php echo e(@array_pop($sentences)); ?> <?php echo e(@array_pop($sentences)); ?> <?php echo e(@array_pop($sentences)); ?> <br>
				<?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a class="badge badge-<?php echo e(collect(['primary', 'secondary', 'success', 'info', 'danger', 'warning', 'light', 'dark'])->random()); ?>" href="<?php echo e(image_url($r)); ?>"><?php echo e($r->title); ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</p>
		<?php endif; ?>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="posts-singles">		
		<div class="posts-content"> 
			<div class="text-left">
				<h3><?php echo e(@array_pop($sentences)); ?></h3>
				<p class="text-center"><img src="<?php echo e(collect($images)->random()['url']); ?>" style="margin-bottom: 8px;"></p>

				<?php $__currentLoopData = collect($sentences)->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked_sentences): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<p>
						<?php if($loop->first): ?>
							<strong><?php echo e(ucfirst($keyword)); ?></strong>. 
						<?php endif; ?>

						<?php $__currentLoopData = $chunked_sentences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked_sentence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php echo e($chunked_sentence); ?> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div> 
		</div> 
	<?php $__currentLoopData = collect($images)->shuffle()->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
			<?php if($loop->iteration == 1): ?>
				<?php $__currentLoopData = $chunked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="posts-picture"> 
						<a href="<?php echo e(preview_url($image)); ?>" target="_blank">
							<img class="img-fluid" src="<?php echo e($image['url']); ?>" alt="<?php echo e($image['title']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';"></a>
						<p class="text-center"><?php echo e($image['title']); ?></p> 
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<?php $__currentLoopData = $chunked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="posts-gallery">
						<div class="posts-gallery-content">
							<a href="<?php echo e(preview_url($image)); ?>" target="_blank">
								<img class="img-fluid" src="<?php echo e($image['url']); ?>" alt="<?php echo e($image['title']); ?>" onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';"></a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
		<div class="clearfix"></div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shuriken\themes\four/image.blade.php ENDPATH**/ ?>